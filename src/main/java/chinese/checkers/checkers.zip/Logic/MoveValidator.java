package chinese.checkers.Logic;

import chinese.checkers.Models.Board;
import chinese.checkers.Models.Cell;

public class MoveValidator {

}
